<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery-3.6.3"></script>
    <title>my task</title>
</head>
<body>
<div class="container-fluid banner">
        <div class="row">
            <div class="col-md-12">
                <div class="navbar">
                    <div class="navbar-brand">
                        <img src="image/logo.jpg">
                          <i>Book Your Room</i>
                    </div>
                    <ul class="nav">
                        <li class="nav-item">
                            <a class="nav-link"href="webpage.php">HOME</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link"href="home.php">ABOUT</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link"href="home.php">GALLERY</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link"href="home.php">CONTACT</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link"href="home.php">LOGIN</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
<section id="body2">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="center">
                <?php
   require("connection.php");
   $cust=$_REQUEST["book"];
   $res=$con->query("select* from `add_room`where`id`='$cust'");
   $count=$res->num_rows;
   if($count>0)
   {
    $row=$res->fetch_assoc();
   }
?>
                    <form action="booking_action.php" method="post" enctype="multipart/form-data">
                        <input type="hidden" class="form-control" name="id" value="<?php echo $cust;?>">
                            <div class="form-group">
                            <label >Name</label>
                            <input type="text" class="form-control"name="name" id="name" placeholder="Enter your name"required>  
                            </div>
                            <div class="form-group">
                            <label >Mobile number</label>
                            <input type="number" class="form-control"name="number" id="number" placeholder="Enter your mobile number"required>  
                            </div>
                            <div class="form-group">
                            <label >Address</label>
                            <input type="text" class="form-control"name="address" id="address" placeholder="Enter your address"required>  
                            </div>
                            <div class="form-group">
                            <label >Checkin Date</label>
                            <input type="date" class="form-control"name="datestart" id="date" placeholder="Enter your booking dates"required>  
                            </div>
                            <label >Checkout Date</label>
                            <input type="date" class="form-control"name="dateend" id="date" placeholder="Enter your booking dates"required><br>
                            <center> <input type="submit" class="btn btn-primary" value="Booknow"> </center>
                            </div> 
                            
                            
                    </form>
                </div>
            </div>
        </div>
    </div>
   </section>
    
</body>
</html>