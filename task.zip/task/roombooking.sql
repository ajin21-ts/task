-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 23, 2023 at 09:47 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `roombooking`
--

-- --------------------------------------------------------

--
-- Table structure for table `add_room`
--

CREATE TABLE `add_room` (
  `id` int(50) NOT NULL,
  `status` int(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `roomimg` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `roomno` varchar(20) NOT NULL,
  `address` varchar(100) NOT NULL,
  `minperiod` varchar(40) NOT NULL,
  `maxperiod` varchar(30) NOT NULL,
  `rent` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `add_room`
--

INSERT INTO `add_room` (`id`, `status`, `email`, `roomimg`, `type`, `roomno`, `address`, `minperiod`, `maxperiod`, `rent`) VALUES
(7, 0, 'priyajin215@gmail.com', 'pexels-photo-2029731.jpeg', 'double bed room', '438', '10-51 koottuvilai  bethelpuram po kanniyakumari distict 629803', '1day', '2 months', '2500/day'),
(8, 0, 'priyajin215@gmail.com', 'pexels-photo-5991565.webp', 'single bed room', '123', '10/20,ooty,ooty main,629804', '1day', '2 months', '1500/day'),
(9, 1, 'ajinameer440@gmail.com', 'pexels-photo-7587288.jpeg', 'double bed room', '234', '11-10 konamkadu,konamkadu(po) kanniyakumari distict 629804', '1day', '3months', '2000Rs/day'),
(10, 1, 'ajinameer440@gmail.com', 'pexels-photo-3773581.jpeg', 'single bed room', '330', '10-51 kanniayakumari,kanniyakumare beach,98096', '1day', '2 months', '1500/day');

-- --------------------------------------------------------

--
-- Table structure for table `admindetail_table`
--

CREATE TABLE `admindetail_table` (
  `admin_id` int(20) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobile` varchar(30) NOT NULL,
  `Password` varchar(30) NOT NULL,
  `confirm_password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admindetail_table`
--

INSERT INTO `admindetail_table` (`admin_id`, `name`, `email`, `mobile`, `Password`, `confirm_password`) VALUES
(1, 'AJIN.T.S', 'ajinameer440@gmail.com', '7397589498', 'ajin', 'ajin'),
(2, 'priyajin', 'priyajin215@gmail.com', '9865179567', 'priyajin', 'priyajin');

-- --------------------------------------------------------

--
-- Table structure for table `booking_room`
--

CREATE TABLE `booking_room` (
  `cust_id` int(30) NOT NULL,
  `id` int(100) NOT NULL,
  `name` varchar(30) NOT NULL,
  `mobile` varchar(50) NOT NULL,
  `address` varchar(150) NOT NULL,
  `fromdate` varchar(20) NOT NULL,
  `todate` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `booking_room`
--

INSERT INTO `booking_room` (`cust_id`, `id`, `name`, `mobile`, `address`, `fromdate`, `todate`) VALUES
(30, 0, 'AJIN.T.S', '7397589498', '10-51 koottuvilai  bethelpuram po kanniyakumari distict 629803', '6544-05-04', '5544-06-07'),
(31, 0, 'priyajin', '7397589498', '10-51 koottuvilai  bethelpuram po kanniyakumari distict 629803', '8790-07-06', '5765-06-05'),
(32, 0, 'AJIN.T.S', '44785962123', '10-51 koottuvilai  bethelpuram po kanniyakumari distict 629803', '8980-07-06', '8766-07-06'),
(33, 0, 'AJIN.T.S', '44785962123', '10-51 koottuvilai  bethelpuram po kanniyakumari distict 629803', '8980-07-06', '8766-07-06'),
(34, 7, 'ajin', '1234587690', '10-51 koottuvilai  bethelpuram po kanniyakumari distict 629803', '2222-02-22', '2222-02-23'),
(35, 9, 'AJIN.T.S', '44785962123', '10-51 koottuvilai  bethelpuram po kanniyakumari distict 629803', '7676-06-05', '7676-06-07'),
(36, 10, 'AJIN.T.S', '7397589498', '10-51 koottuvilai  bethelpuram po kanniyakumari distict 629803', '0909-08-07', '7655-07-06');

-- --------------------------------------------------------

--
-- Table structure for table `customerdetail_table`
--

CREATE TABLE `customerdetail_table` (
  `cust_id` int(30) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(40) NOT NULL,
  `mobile` varchar(50) NOT NULL,
  `password` varchar(30) NOT NULL,
  `confirm_password` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customerdetail_table`
--

INSERT INTO `customerdetail_table` (`cust_id`, `name`, `email`, `mobile`, `password`, `confirm_password`) VALUES
(1, 'Ajin Ameer', '21ajints2000@gmail.com', '7397589498', 'ajin215', 'ajin215'),
(2, 'ajin', 'ajinameer440@gmail.com', '1234587690', 'ajin215', 'ajin215');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `add_room`
--
ALTER TABLE `add_room`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admindetail_table`
--
ALTER TABLE `admindetail_table`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `booking_room`
--
ALTER TABLE `booking_room`
  ADD PRIMARY KEY (`cust_id`);

--
-- Indexes for table `customerdetail_table`
--
ALTER TABLE `customerdetail_table`
  ADD PRIMARY KEY (`cust_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `add_room`
--
ALTER TABLE `add_room`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `admindetail_table`
--
ALTER TABLE `admindetail_table`
  MODIFY `admin_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `booking_room`
--
ALTER TABLE `booking_room`
  MODIFY `cust_id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `customerdetail_table`
--
ALTER TABLE `customerdetail_table`
  MODIFY `cust_id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
