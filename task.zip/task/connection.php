<?php
$con=mysqli_connect("localhost","root","","roombooking");
if(!$con)
{
    echo("connection failed");
}

?>