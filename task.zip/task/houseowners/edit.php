<?php
require("connection.php");
$id=$_REQUEST["id"];
$type=$_REQUEST["type"];
$number=$_REQUEST["number"];
$address=$_REQUEST["address"];
$minper=$_REQUEST["minperiod"];
$maxper=$_REQUEST["maxperiod"];
$rent=$_REQUEST["rent"];
if(empty($_FILES["roomimg"]["name"]))
{
   $res=$con->query("update `add_room` set type='$type',roomno='$number',address='$address',minperiod='$minper',maxperiod='$maxper',rent='$rent'where id='$id'");
    $count=mysqli_affected_rows($con);
    echo"<script> alert('you have update successfully'); window.location='viewroom.php';</script>";

}
else
{
    $room=$_FILES["roomimg"]["name"];
    $res=$con->query("update `add_room` set roomimg='$room',type='$type',roomno='$number',address='$address',minperiod='$minper',maxperiod='$maxper',rent='$rent'where id='$id'");
    $count=mysqli_affected_rows($con);
    move_uploaded_file($_FILES["roomimg"]["tmp_name"],"rooms images/".$room);
    echo"<script> alert('you have update successfully'); window.location='viewroom.php'; </script>";
} 
?>
    
    