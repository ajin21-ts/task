<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery-3.6.3"></script>
    <title>my task</title>
</head>
<body>
<section id="body">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="center">
                <div class="container">
                <?php
   require("connection.php");
   $user=$_REQUEST["update"];
   $res=$con->query("select* from `add_room`where`id`='$user'");
   $count=$res->num_rows;
   if($count>0)
   {
      $row=$res->fetch_assoc();
   }
?>
  <form action="edit.php" method="post" enctype="multipart/form-data">
    <input type="hidden" class="form-control" name="id" value="<?php echo$row["id"]?>">
        <div class="form-group">
	        <label for="fundate">Room photo</label><br>
            <img src="<?php echo "rooms images/".$row["roomimg"];?>" width="100px" height="100px">
	        <input type="file"class="form-control"name="roomimg"value="<?php echo$row["roomimg"]?>"id="roomimg">
        </div>
        <div class="form-group">
            <label >Room Type</label>
            <input type="text" class="form-control"name="type"value="<?php echo$row["type"]?>" id="type" placeholder="Enter your room type">  
        </div>
        <div class="form-group">
            <label >Room Number</label>
            <input type="text" class="form-control"name="number"value="<?php echo$row["roomno"]?>" id="number" placeholder="Enter your room number">  
        </div>
        <div class="form-group">
            <label >Address</label>
            <input type="text" class="form-control"name="address"value="<?php echo$row["address"]?>" id="address" placeholder="Enter your room address">  
        </div>
        <div class="form-group">
            <label >Minimun Booking Period</label>
            <input type="text" class="form-control"name="minperiod"value="<?php echo$row["minperiod"]?>" id="period" placeholder="Enter your minimum period of booking">  
        </div>
        <div class="form-group">
            <label >Maximum Booking period</label>
            <input type="text" class="form-control"name="maxperiod"value="<?php echo$row["maxperiod"]?>" id="period" placeholder="Enter your maximum period of booking">  
        </div>
        <div class="form-group">
            <label >Room Rent/Day</label>
            <input type="text" class="form-control"name="rent"value="<?php echo$row["rent"]?>" id="roomrent" placeholder="Enter your room rent">  
        </div>
  <center><input type="submit" class="btn btn-primary" value="edit"></center>
</form>
  </div>
                </div>
            </div>
        </div>
    </div>
   </section>
    
</body>
</html>