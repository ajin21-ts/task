<?php
session_start();
require("connection.php");
$email=$_REQUEST["email"];
$password=$_REQUEST["pwd"];
$message=("Enter a valid password and email!..");
$res=$con->query("select*from`admindetail_table` where `email`='$email'AND`password`='$password'");
$count=$res->num_rows;
if($count>0)
{
    $_SESSION["email"]=$email;
    header("location:dashboard.php");
}
else
{
   echo"<script type='text/javascript'>alert('$message');window.location.href='adminlogin.php';</script>";
}

?>