<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery-3.6.3"></script>
    <title>my task</title>
</head>
<body>
   <section id="head">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                    <div class="logo">
                        <center><h1>HOUSEOWNER</h1></center>
                    </div>
                </div>  
            </div>
        </div>
    </section>  
    <section id="login">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="center">
                        <div class="container-fluid">
                            <div class="row justify-content-center">
                                <div class="card w-30">
                                    <div class="card-header bg-primary">
                                    <h1>LOGIN</h1>
                                    </div>
                                <div class="card-body">
                                    <form action="adlogin_action.php"method="post">
                                        <div class="form-group">
                                            <label for="email">Email</label>
                                            <input type="email" name="email" class="form-control" id="email"placeholder="enter your email"required>
                                        </div>
                                        <div class="form-group">
                                            <label for="password">Password</label>
                                            <input type="password" name="pwd"class="form-control" id="password"placeholder="enter your passwod"required>
                                        </div>
                                        <input type="submit" class="btn btn-primary w-100 " value="Login">
                                    </form>
                                </div>
                                <div class="card-footer">
                                   <p>don't have an account?<a href="adminregister.php"> Register now!!</a></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section> 
</body>
</html>