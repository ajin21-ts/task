<?php
require("connection.php");
$cust=$_REQUEST["delete"];
$res=$con->query("select * from`add_room` where id='$cust'");
$count=$res->num_rows;
if($count>0)
{
   
    
        $row=$res->fetch_assoc();
        $ph=$row["roomimg"];
        unlink("rooms images/$room");
        $res=$con->query("delete from `add_room` where `id`='$cust'");
        $count=mysqli_affected_rows($con);
        header("location:viewroom.php");
       
        
    
    
}
?>

