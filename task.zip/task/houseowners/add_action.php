<?php
session_start();
require("connection.php");
$email=$_SESSION["email"];
$room=$_FILES["roomimg"]["name"];
$type=$_REQUEST["type"];
$number=$_REQUEST["number"];
$address=$_REQUEST["address"];
$minper=$_REQUEST["minperiod"];
$maxper=$_REQUEST["maxperiod"];
$rent=$_REQUEST["rent"];
$res=$con->query("insert into `add_room`(`email`,`roomimg`,`type`,`roomno`,`address`,`minperiod`,`maxperiod`,`rent`)values('$email','$room','$type','$number','$address','$minper','$maxper','$rent')");
$count=mysqli_affected_rows($con);
echo 

     move_uploaded_file($_FILES["roomimg"]["tmp_name"],"rooms images/".$room);
if($count>0){

     echo"<script type='text/javascript'>alert('Room added sucessfully');window.location.href='viewroom.php';</script>";
     }
?>
   
