<!DOCTYPE html>
<?php
session_start();
$email=$_SESSION["email"];
if(empty($_SESSION["email"]))
{
	header("location:login.php");
}
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery-3.6.3"></script>
    <title>my task</title>
</head>
<body>
   <section id="head">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="logo">
                    <center><h1>HOUSEOWNER</h1></center>
                    <center><h2><?php echo $email?></h2></center>
                </div>
            </div>
        </div>
    </div>
   </section>
   <section id="body">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <div class="left">
                    <a href="addroom.php" class="btn btn-success">Add Rooms</a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="left">
                    <a href="viewbooking.php" class="btn btn-success">View Bookings</a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="right">
                <a href="viewroom.php" class="btn btn-success">View Rooms</a>
                    
                </div>
                  
                </div>
            </div>
        </div >
    </div>
   </section>
</body>
</html>



                    