<!DOCTYPE html>
<?php
session_start();
$email=$_SESSION["email"];
if(empty($_SESSION["email"]))
{
	header("location:login.php");
}
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery-3.6.3"></script>
    <title>my task</title>
</head>
<body>

<section id="head">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="logo">
                    <center><h1>HOUSEOWNER</h1></center>
                    <center><h2><?php echo $email?></h2></center>
                </div>
            </div>
        </div>
    </div>
   </section>

<section id="body">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="center">
        <table class="table">
  <thead>
    <tr>
      <th>SI.NO</th>
      <th>ROOM IMAGES</th>
      <th>ROOM TYPE</th>
      <th>ROOM NUMBER</th>
      <th>ADDRESS</th>
      <th>MINIMUM PERIOD</th>
      <th>MAXIMUM PERIOD</th>
      <th>ROOM RENT</th>
      <th>UPDATE</th>
      <th>DELETE</th>
    </tr>
  </thead>
  <?php
    require("connection.php");
    $res=$con->query("select*from`add_room` where `email`='$email'");
    $count=$res->num_rows;
    if($count>0)
    {
        $count=0;
        while($row=$res->fetch_assoc())
        {
          $count+=1;


?>
  <tr>
      <td><?php echo $count;?></td>
      <td><img src="<?php echo "rooms images/".$row["roomimg"];?>"width="100px" height="100px"></td>
      <td><?php echo $row["type"]?></td>
      <td><?php echo $row["roomno"]?></td>
      <td><?php echo $row["address"]?></td>
      <td><?php echo $row["minperiod"]?></td>
      <td><?php echo $row["maxperiod"]?></td>
      <td><?php echo $row["rent"]?></td>
      <td><a class="btn btn-success"href="update.php?update=<?php echo $row["id"];?>">update</a></td>
      <td><a class="btn btn-danger"href="delete.php?delete=<?php echo $row["id"];?>"onclick="return confirm('Are you sure to delete this data!!')">Delete</a></td>
    <?php
        }
    }
    ?>    
            </div>
  </div>
  </div>
  </div>
  </table>
  </section>    
</body>
</html>