<!DOCTYPE html>
<?php
session_start();
$email=$_SESSION["email"];
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery-3.6.3"></script>
    <title>my task</title>
</head>
<body>
<section id="head">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="logo">
                    <center><h1>HOUSEOWNER</h1></center>
                    <center><h2><?php echo $email?></h2></center>
                </div>
            </div>
        </div>
    </div>
   </section>
   
<section id="body2">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="center">
                    <form action="add_action.php" method="post" enctype="multipart/form-data">
                            <div class="form-group">
	                        <label for="fundate">Room photo</label>
	                        <input type="file"class="form-control"name="roomimg"id="roomimg">
                            </div>
                            <div class="form-group">
                            <label >Room Type</label>
                            <input type="text" class="form-control"name="type" id="type" placeholder="Enter your room type"required>  
                            </div>
                            <div class="form-group">
                            <label >Room Number</label>
                            <input type="text" class="form-control"name="number" id="number" placeholder="Enter your room number"required>  
                            </div>
                            <div class="form-group">
                            <label >Address</label>
                            <input type="text" class="form-control"name="address" id="address" placeholder="Enter your room address"required>  
                            </div>
                            <div class="form-group">
                            <label >Minimun Booking Period</label>
                            <input type="text" class="form-control"name="minperiod" id="period" placeholder="Enter your minimum period of booking"required>  
                            </div>
                            <div class="form-group">
                            <label >Maximum Booking period</label>
                            <input type="text" class="form-control"name="maxperiod" id="period" placeholder="Enter your maximum period of booking"required>  
                            </div>
                            <div class="form-group">
                            <label >Room Rent/Day</label>
                            <input type="text" class="form-control"name="rent" id="roomrent" placeholder="Enter your room rent"required>  
                            </div>
                            
                           <center> <input type="submit" class="btn btn-primary" value="Submit"> </center>
                    </form>
                </div>
            </div>
        </div>
    </div>
   </section>

    
</body>
</html>