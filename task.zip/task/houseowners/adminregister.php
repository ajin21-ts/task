<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery-3.6.3"></script>
    <title>my task</title>
</head>
<body>
<section id="head">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                    <div class="logo">
                        <center><h1>HOUSEOWNER</h1></center>
                    </div>
                </div>  
            </div>
        </div>
    </section>
<section id="body">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="center">
                    <div class="container-fluid box">
                        <div class="row justify-content-center">
                            <div class="card w-30">
                                <div class="card-header bg-primary ">
                                    <h1>REGISTER NOW</h1>
                                </div>
                                <div class="card-body">
                                    <form action="adreg_action.php" method="post">
                                        <div class="form-group">
                                            <label for="email">Name</label>
                                            <input type="text" name="name" class="form-control" id="name"placeholder="enter your name" required>
                                        </div>
                                        <div class="form-group">
                                            <label for="email">Email</label>
                                            <input type="email" name="email" class="form-control" id="email"placeholder="enter your email"required>
                                        </div>
                                        <div class="form-group">
                                            <label for="email">Mobile Number</label>
                                            <input type="number" name="number" class="form-control" id="number"placeholder="enter your mobile number"required>
                                        </div>
                                        <div class="form-group">
                                            <label for="password">Password</label>
                                            <input type="password" name="pwd"class="form-control" id="password"placeholder="enter your passwod"required>
                                        </div>
                                        <div class="form-group">
                                            <label for="password">Confirm Password</label>
                                            <input type="password" name="conpwd"class="form-control" id="confirmpassword"placeholder="enter your passwod once again"required>
                                        </div>
                                        <input type="submit" class="btn btn-primary w-100 " value="Login">
                                    </form>
                                </div>
                                    <div class="card-footer">
                                    <p>Already have an account?<a href="index.php"> Login now!!</a></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</section>
    
</body>
</html>