<!DOCTYPE html>
<?php
session_start();
$email=$_SESSION["email"];
if(empty($_SESSION["email"]))
{
	header("location:login.php");
}
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery-3.6.3"></script>
    <title>my task</title>
</head>
<body>
<section id="body">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="center">
                <?php
    require("connection.php");
    $res=$con->query("select*from`booking_room` where `mail`='$email'");
    $count=$res->num_rows;
    if($count>0)
    {
      ?>
        <table class="table">
  <thead>
    <tr>
      <th>SI.NO</th>
      <th>NAME</th>
      <th>MOBILE NUMBER</th>
      <th>ADDRESS</th>
      <th>CHECK IN </th>
      <th>CHECK OUT</th>
    </tr>
  </thead>
<?php
        $count=0;
        while($row=$res->fetch_assoc())
        {
          $count+=1;


?>
  <tr>
      <td><?php echo $count;?></td>
      <td><?php echo $row["name"]?></td>
      <td><?php echo $row["mobile"]?></td>
      <td><?php echo $row["address"]?></td>
      <td><?php echo $row["fromdate"]?></td>
      <td><?php echo $row["todate"]?></td>
        </tr>
    <?php
        }
    }
    
    
    else{
      echo "<h2 class='text text-center'>NO BOOKING AVILABLE!!..</h2>";
    }
    ?>
            </div>
  </div>
  </div>
  </div>
  </table>
  </section>    
    
</body>
</html>