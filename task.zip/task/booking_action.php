<?php
session_start();
require("connection.php");
$cid=$_REQUEST["id"];
$name=$_REQUEST["name"];
$number=$_REQUEST["number"];
$address=$_REQUEST["address"];
$fromdate=$_REQUEST["datestart"];
$todate=$_REQUEST["dateend"];
$res=$con->query("insert into `booking_room`(`id`,`name`,`mobile`,`address`,`fromdate`,`todate`)values('$cid','$name','$number','$address','$fromdate','$todate')");
$count=mysqli_affected_rows($con);

if($count>0){
     $res=$con->query("update `add_room` set `status`='1'where`id`='$cid'");
     $count=mysqli_affected_rows($con);

     echo"<script type='text/javascript'>alert('Room added sucessfully');window.location.href='webpage.php';</script>";
     }
?>
   
