<?php
require("connection.php");
$email=$_REQUEST["email"];
$password=$_REQUEST["pwd"];
$message=("Enter a valid password and email!..");
$res=$con->query("select*from`customerdetail_table` where `email`='$email'AND`password`='$password'");
$count=$res->num_rows;
if($count>0)
{
    header("location:webpage.php");
}
else
{
   echo"<script type='text/javascript'>alert('$message');window.location.href='customerlogin.php';</script>";
}

?>