<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery-3.6.3"></script>
    <title>my task</title>
</head>
<body>
    <div class="container-fluid banner">
        <div class="row">
            <div class="col-md-12">
                <div class="navbar">
                    <div class="navbar-brand">
                        <img src="image/logo.jpg">
                          <i>Book Your Room</i>
                    </div>
                    <ul class="nav">
                        <li class="nav-item">
                            <a class="nav-link"href="webpage.php">HOME</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link"href="home.php">ABOUT</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link"href="home.php">GALLERY</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link"href="home.php">CONTACT</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link"href="home.php">LOGOUT</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
<section id="center">
                            <?php
								require("connection.php");
								$res=$con->query("select * from `add_room`");
								$count=$res->num_rows;
								if($count>0)
								{
									while($row=$res->fetch_assoc())
										{

                            ?>
                                         <div class="container-fluid body">
                                            <div class="row">
                                                <div class="body-left">
                                                    <div class="col-md-12">
                                                        <?php echo '<img  width="200" height="200"src="houseowners/rooms images/'.$row["roomimg"].'">';?><br><br>
                                                        <p><b>Room Type </b>: <?php echo $row["type"];?></p>
                                                        <p><b>Location </b>: <?php echo $row["address"];?></p>
                                                        <p><b>Rent/day </b>: <?php echo $row["rent"];?></p>
                                                        <?php
                                                        if($row["status"]==1){
                                                             echo "<h4 class='text-danger'>already booked!!..</h4>";
                                                        }
                                                        else{

                                                        ?>
                                                        <a href="booknow.php?book=<?php echo $row["id"];?>" class="btn btn-success">Book Now</a>
                                                        <?php
                                                        }
                                                        ?>

                                                    </div>
                                                </div>
                                        <?php
                                        }
                                    }

                                     ?>
    
        </div>   
   </div>
</section>
</body>
</html>

