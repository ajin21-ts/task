<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery-3.6.3"></script>
    <title>Document</title>
</head>
<body>
<section id="top">
    <div class="container-fluid logo">
        <div class="row">
            <div class="col-md-12">
                        <img src="image/logo.jpg">
            </div>
        </div>
    </div>
</section>
<section id="index">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-12">
                                        <h2>Welcome To Our Website</h2>
                                        <a href="customerlogin.php" class="btn btn-primary">Login</a>
                                    </div>
                                </div>
                            </div>
</section>
</body>
</html>

